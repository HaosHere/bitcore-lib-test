//var Peer = require('/home/hao/Desktop/bitcore_lib/bitcore-p2p.min.js').Peer;
//var bitcore =require('/home/hao/Desktop/bitcore_lib/bitcore-lib.min.js');
var bitcore =require('/home/hao/bitcore-lib');
delete global._bitcore;
var Peer = require('/home/hao/bitcore-p2p').Peer;
delete global._bitcore;
var message = require('home/hao/bitcore-message');
var peer = new Peer({host: '127.0.0.1', port: 6543});

peer.on('ready', function() {
  // peer info
  console.log(peer.version, peer.subversion, peer.bestHeight);
var privateKey = new bitcore.PrivateKey();
var address = privateKey.toAddress();
console.log(address);
});
peer.on('disconnect', function() {
  console.log('connection closed');
});
peer.connect();

